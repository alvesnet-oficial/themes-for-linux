/**
 * Conica Theme Custom Functionality
 *
 */
( function( $ ) {
    
    jQuery( document ).ready( function() {
        
        $('.header-stick').waypoint('sticky', {
            offset: 0
        });
		
    });
    
} )( jQuery );